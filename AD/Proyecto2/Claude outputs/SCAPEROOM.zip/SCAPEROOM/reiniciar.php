<?php
// reiniciar.php  ->  borra la partida y vuelve al inicio
session_start();
$_SESSION = [];
session_destroy();
header("Location: hab0.php");
exit;
