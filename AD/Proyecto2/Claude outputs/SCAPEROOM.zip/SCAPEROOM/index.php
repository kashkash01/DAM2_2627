<?php
// index.php  ->  la entrada del juego es la habitación 0
header("Location: hab0.php");
exit;
